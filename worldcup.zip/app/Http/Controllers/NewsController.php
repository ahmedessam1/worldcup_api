<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\News;

class NewsController extends Controller
{
    public function index()
    {
        return News::with('media')->with('tags')->paginate(10);
    }

    public function show($id)
    {
        return News::with('media')->with('tags')->find($id);
    }
}

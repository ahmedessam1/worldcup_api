<?php

namespace App\Http\Controllers;

use App\Video;
use Illuminate\Http\Request;

class VideosController extends Controller
{
    public function index()
    {
        return Video::paginate(10);
    }

    public function show($id)
    {
        return Video::find($id);
    }

    public function search(Request $q)
    {
        $query = $q->q;
        $result = Video::where('title', 'LIKE', '%'.$query.'%')->limit(15)->get();
        return $result;
    }
}

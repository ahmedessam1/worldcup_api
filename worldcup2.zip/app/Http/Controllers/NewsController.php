<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\News;

class NewsController extends Controller
{
    public function index()
    {
        return News::with('media')->with('tags')->paginate(10);
    }

    public function show($id)
    {
        return News::with('media')->with('tags')->find($id);
    }

    public function search(Request $q)
    {
        $query = $q->q;
        $result = News::with('media')->with('tags')->where('title', 'LIKE', '%'.$query.'%')->orWhereHas('tags', function($q) use ($query) {
            $q->where('name', 'LIKE', '%'.$query.'%');
        })->limit(15)->get();
        return $result;
    }
}

<?php

namespace App\Http\Controllers;

use App\Transportation;
use Illuminate\Http\Request;

class TransportationController extends Controller
{
    public function index(Request $request)
    {
        try {
            $date = $request->date;
            if($date)
                $collection = Transportation::where('date', $date)->get();
            else
                $collection = Transportation::all();

            $data = ['data' => $collection, 'status' => true, 'message' => "success"];
            return $data;
        } catch (\Exception $e) {
            return ['status' => false, 'message' => "something went wrong"];
        }
    }
}
